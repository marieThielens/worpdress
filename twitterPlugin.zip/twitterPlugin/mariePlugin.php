<?php
/*
Plugin Name: twitter Plugin
Description: Un plugin d'introduction pour le développement sous WordPress
Version: 1.0
Author: Thielens Marie
Author URI: https://www.thielens-marie.be
License: GPL2
*/

class MariePlugin
{
    public function __construct()
    {
        include_once plugin_dir_path( __FILE__). '/twitterwidget.php';
        new Twitter_widget(); 
    }
}
new MariePlugin();
